from PortMap import *
from MissionBase import *
from Actions import *
from BasicDriveActions import *
from Estimation import *
class LastMission(MissionBase):
    def routine(self):
        #self.runAction(DriveStraightAction(1000))
        self.runAction(DriveTurnAction(45))
        self.runAction(DriveStraightAction(1000))
        
        
        #runAction()


if __name__ == "__main__": #run on file run but not import
    LastMission()

lastMission = LastMission()
lastMission.run()