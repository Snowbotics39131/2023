from PortMap import *
from BasicDriveActions import *
DriveStraightAction(680).run()
DriveTurnAction(45).run()
DriveStraightAction(120).run()
DriveStraightAction(-150).run()
DriveTurnAction(-145).run()
DriveStraightAction(1050).run()
DriveTurnAction(45).run()
DriveStraightAction(200).run()
DriveTurnAction(-90).run()
DriveStraightAction(240).run()
DriveTurnAction(-45).run()
DriveStraightAction(260).run()