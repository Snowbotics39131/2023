from PortMap_for_BUGBOT import *

#mode = "straight"
mode = 'not'
#if mode == "attatchment":
driveBase.straight(-500)